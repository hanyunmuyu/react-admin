export interface IRole {
    id: number
    roleName: string
}