export enum PermissionType {
    GET,
    SET
}