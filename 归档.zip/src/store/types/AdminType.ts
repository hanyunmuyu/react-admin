export enum AdminType {
    LOADING,
    GET,
    LOGIN,
    LOGOUT,
    SET,
    DEL
}